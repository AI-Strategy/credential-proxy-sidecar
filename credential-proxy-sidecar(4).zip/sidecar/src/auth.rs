use jsonwebtoken::{decode, DecodingKey, Validation, Algorithm, TokenData};
use serde::Deserialize;

#[derive(Debug, Deserialize)]
pub struct Claims {
    pub sub: String,
    pub aud: String,
    pub exp: usize,
    pub scope: String,
}

pub fn verify_jwt(token: &str, pubkey_pem: &str) -> Result<TokenData<Claims>, jsonwebtoken::errors::Error> {
    decode::<Claims>(
        token,
        &DecodingKey::from_rsa_pem(pubkey_pem.as_bytes()).unwrap(),
        &Validation::new(Algorithm::RS256),
    )
}