use axum::{Json};
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
pub struct OpenAIRequest {
    pub prompt: String,
    pub client_id: String,
}

#[derive(Serialize)]
pub struct OpenAIResponse {
    pub result: String,
}

pub async fn ask_openai(Json(payload): Json<OpenAIRequest>) -> Json<OpenAIResponse> {
    Json(OpenAIResponse {
        result: format!("Echo: {}", payload.prompt),
    })
}