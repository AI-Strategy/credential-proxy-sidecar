use axum::{Json};
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
pub struct AstraRequest {
    pub query: String,
    pub client_id: String,
}

#[derive(Serialize)]
pub struct AstraResponse {
    pub rows: Vec<String>,
}

pub async fn query_astra(Json(payload): Json<AstraRequest>) -> Json<AstraResponse> {
    Json(AstraResponse {
        rows: vec![format!("stub row for: {}", payload.query)],
    })
}