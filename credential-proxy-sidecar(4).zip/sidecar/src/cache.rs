use std::collections::HashMap;
use std::sync::Mutex;
use once_cell::sync::Lazy;

static CACHE: Lazy<Mutex<HashMap<String, String>>> = Lazy::new(|| Mutex::new(HashMap::new()));

pub fn get_token(client_id: &str) -> Option<String> {
    let cache = CACHE.lock().unwrap();
    cache.get(client_id).cloned()
}

pub fn set_token(client_id: &str, token: &str) {
    let mut cache = CACHE.lock().unwrap();
    cache.insert(client_id.to_string(), token.to_string());
}