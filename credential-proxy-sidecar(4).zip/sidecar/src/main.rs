use axum::Router;
use std::net::SocketAddr;
mod auth;
mod router;
mod cache;
mod config;

#[tokio::main]
async fn main() {
    let app = router::build_router();
    let addr = SocketAddr::from(([0, 0, 0, 0], 7080));
    println!("Sidecar running on {}", addr);
    axum::Server::bind(&addr).serve(app.into_make_service()).await.unwrap();
}