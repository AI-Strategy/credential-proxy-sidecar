use axum::{Router, routing::post};
use crate::handlers::{openai::ask_openai, astra::query_astra};

pub fn build_router() -> Router {
    Router::new()
        .route("/ask-openai", post(ask_openai))
        .route("/query-astra", post(query_astra))
}