use axum::{Router, routing::get};
use std::net::SocketAddr;

mod audit;
mod fetch_secret;
mod auth;
mod metrics;
mod session;

#[tokio::main]
async fn main() {
    let app = Router::new()
        .route("/healthz", get(|| async { "Proxy OK" }))
        .merge(metrics::routes());

    let addr = SocketAddr::from(([0, 0, 0, 0], 7070));
    println!("Proxy running on {}", addr);
    axum::Server::bind(&addr).serve(app.into_make_service()).await.unwrap();
}