import React, { useState } from "react";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");

  const handleAsk = async () => {
    const res = await fetch("/ask-openai", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer test.jwt.token"
      },
      body: JSON.stringify({ client_id: "workflow-17", prompt })
    });
    const data = await res.json();
    setResult(data.result || JSON.stringify(data));
  };

  return (
    <div className="p-4 font-sans">
      <h1 className="text-xl mb-4">Credential Sidecar UI</h1>
      <input
        className="border p-2 mb-2 w-full"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Ask OpenAI something..."
      />
      <button onClick={handleAsk} className="bg-blue-600 text-white px-4 py-2 rounded">
        Submit
      </button>
      <pre className="mt-4 bg-gray-100 p-2 rounded">{result}</pre>
    </div>
  );
}