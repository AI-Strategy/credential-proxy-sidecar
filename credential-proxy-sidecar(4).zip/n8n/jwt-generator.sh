#!/bin/bash
# Generates a dummy JWT
HEADER='{"alg":"RS256","typ":"JWT"}'
PAYLOAD='{"sub":"workflow-17","aud":"openai","exp":'$(($(date +%s)+600))',"scope":"readonly"}'
echo -n $HEADER | openssl base64 -e | tr -d '=' | tr '/+' '_-' > header.b64
echo -n $PAYLOAD | openssl base64 -e | tr -d '=' | tr '/+' '_-' > payload.b64
echo "$(cat header.b64).$(cat payload.b64).stub_signature"