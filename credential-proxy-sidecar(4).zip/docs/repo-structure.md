# Repo Structure
Full breakdown of files and services used in credential-proxy-sidecar.