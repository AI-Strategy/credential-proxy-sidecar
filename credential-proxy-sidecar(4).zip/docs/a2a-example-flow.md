# A2A Flow
Example workflow from orchestrator through sidecar to external service.