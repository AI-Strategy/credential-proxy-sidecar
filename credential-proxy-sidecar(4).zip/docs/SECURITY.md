# Security Policy
This project uses JWT + scoped API proxying to protect credentials. Secrets are never exposed to orchestrators.