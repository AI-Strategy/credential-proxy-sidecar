# Design Overview
Architecture, flow, threat model, and security hardening of the credential sidecar and proxy.